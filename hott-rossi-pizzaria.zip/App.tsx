
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Pizza, CartItem, OrderData, SiteConfig, UserProfile } from './types';
import { MENU_ITEMS, PIZZARIA_PHONE, DEFAULT_CONFIG } from './constants';
import { saveOrder, getMenu, updateMenu, getConfig, updateConfig } from './services/firebaseService';
import { startChefChat, getCartFeedback } from './services/geminiService';
import PizzaCard from './components/PizzaCard';

const ADMIN_PASSWORD = "116289";

const App: React.FC = () => {
  const [menu, setMenu] = useState<Pizza[]>([]);
  const [isLoadingMenu, setIsLoadingMenu] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [activeTab, setActiveTab] = useState<'menu' | 'admin'>('menu');

  // Site Configuration & Branding
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(DEFAULT_CONFIG);
  const [isUpdatingConfig, setIsUpdatingConfig] = useState(false);

  // User Profile
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('hott-rossi-user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [profileForm, setProfileForm] = useState<UserProfile>({
    name: '', phone: '', rua: '', numero: '', bairro: '', complemento: ''
  });

  // IA Chat
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const [aiChatInstance, setAiChatInstance] = useState<any>(null);
  const [aiMessages, setAiMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);

  // Cart & Checkout
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('hott-rossi-cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [payment, setPayment] = useState('');
  const [changeFor, setChangeFor] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isOrderFinished, setIsOrderFinished] = useState(false);
  
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('All');
  const [chefTip, setChefTip] = useState('');
  
  const cartRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Loading Data
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [remoteMenu, remoteConfig] = await Promise.all([getMenu(), getConfig()]);
        if (remoteMenu) setMenu(remoteMenu); 
        else { await updateMenu(MENU_ITEMS); setMenu(MENU_ITEMS); }
        if (remoteConfig) setSiteConfig({ ...DEFAULT_CONFIG, ...remoteConfig });
      } catch (e) { setMenu(MENU_ITEMS); } finally { setIsLoadingMenu(false); }
    };
    fetchInitialData();
  }, []);

  useEffect(() => {
    localStorage.setItem('hott-rossi-cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (userProfile) setProfileForm(userProfile);
  }, [userProfile]);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isAiChatOpen) scrollToBottom();
  }, [aiMessages, isAiTyping]);

  // Admin Actions
  const handleAdminAuth = () => {
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setIsAuthModalOpen(false);
      setPasswordInput('');
      setActiveTab('admin');
    } else {
      alert("Senha incorreta!");
    }
  };

  const handleUpdateProduct = (updatedPizza: Pizza) => {
    setMenu(prev => prev.map(p => p.id === updatedPizza.id ? updatedPizza : p));
  };

  const handleAddProduct = () => {
    const newPizza: Pizza = {
      id: Date.now(),
      name: "Nova Pizza",
      description: "Descrição da pizza...",
      price: 0,
      category: "Pizza",
      image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=400"
    };
    setMenu(prev => [newPizza, ...prev]);
  };

  const handleDeleteProduct = (id: number) => {
    if (confirm("Deseja remover este produto?")) {
      setMenu(prev => prev.filter(p => p.id !== id));
    }
  };

  const saveAdminChanges = async () => {
    setIsUpdatingConfig(true);
    try {
      await Promise.all([updateMenu(menu), updateConfig(siteConfig)]);
      alert("Configurações salvas com sucesso!");
    } catch (e) {
      alert("Erro ao salvar.");
    } finally {
      setIsUpdatingConfig(false);
    }
  };

  // Chat Logic
  const openAiChat = () => {
    setIsAiChatOpen(true);
    if (!aiChatInstance) {
      const chat = startChefChat(menu);
      setAiChatInstance(chat);
      const welcome = userProfile 
        ? `Benvenuti, ${userProfile.name}! 👋 Estou pronto para te guiar pela melhor pizza da ${siteConfig.appName}. O que te apetece hoje?`
        : `Ciao! Eu sou o Chef ${siteConfig.appName}. 🧑‍🍳 Como posso te ajudar a escolher a pizza perfeita hoje?`;
      setAiMessages([{ role: 'model', text: welcome }]);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent, overrideText?: string) => {
    e?.preventDefault();
    const textToSend = overrideText || userInput;
    if (!textToSend.trim() || isAiTyping) return;
    setUserInput('');
    setAiMessages(prev => [...prev, { role: 'user', text: textToSend }]);
    setIsAiTyping(true);
    try {
      const response = await aiChatInstance.sendMessage({ message: textToSend });
      setAiMessages(prev => [...prev, { role: 'model', text: response.text }]);
    } catch (error) {
      setAiMessages(prev => [...prev, { role: 'model', text: 'Scusa! Tive um problema com o forno... pode repetir?' }]);
    } finally {
      setIsAiTyping(false);
    }
  };

  // Cart Actions
  const addToCart = (pizza: Pizza) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === pizza.id);
      if (existing) return prev.map(item => item.id === pizza.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...pizza, quantity: 1 }];
    });
    cartRef.current?.classList.add('animate-bounce');
    setTimeout(() => cartRef.current?.classList.remove('animate-bounce'), 500);
  };

  // Added fix: Implementation of addToCartFromChat to handle pizza name buttons from the AI Chef chat.
  const addToCartFromChat = (pizzaName: string) => {
    const pizza = menu.find(p => p.name.toLowerCase() === pizzaName.toLowerCase());
    if (pizza) {
      addToCart(pizza);
    }
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: item.quantity + delta } : item).filter(item => item.quantity > 0));
  };

  const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  // Checkout Logic
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('hott-rossi-user', JSON.stringify(profileForm));
    setUserProfile(profileForm);
    setIsProfileModalOpen(false);
  };

  const handleSubmitOrder = async () => {
    if (!userProfile) { setIsProfileModalOpen(true); return; }
    if (cart.length === 0) { alert("Sua sacola está vazia!"); return; }
    if (!payment) { alert("Escolha o método de pagamento!"); return; }
    
    setIsProcessing(true);
    const orderData: OrderData = { 
      cliente: userProfile.name, telefone: userProfile.phone, 
      endereco: { rua: userProfile.rua, numero: userProfile.numero, bairro: userProfile.bairro, complemento: userProfile.complemento }, 
      pagamento: payment, troco: payment === 'Dinheiro' ? changeFor : undefined, 
      itens: cart, total: total, data_hora: new Date().toLocaleString('pt-BR') 
    };

    try {
      await saveOrder(orderData);
      setIsOrderFinished(true);
      let msg = `*🍕 NOVO PEDIDO - ${siteConfig.appName.toUpperCase()}*\n`;
      msg += `------------------------------------------\n`;
      msg += `*👤 CLIENTE:* ${userProfile.name}\n`;
      msg += `*📱 CONTATO:* ${userProfile.phone}\n\n`;
      msg += `*📍 ENTREGA:* ${userProfile.rua}, ${userProfile.numero}\n`;
      msg += `*🏘️ BAIRRO:* ${userProfile.bairro}${userProfile.complemento ? ` (${userProfile.complemento})` : ''}\n\n`;
      msg += `*💳 PAGAMENTO:* ${payment}${payment === 'Dinheiro' ? ` (Troco: ${changeFor})` : ''}\n\n`;
      msg += `*🛒 ITENS:*\n`;
      cart.forEach(item => msg += `• ${item.quantity}x ${item.name} - R$ ${(item.price * item.quantity).toFixed(2)}\n`);
      msg += `\n*💰 TOTAL: R$ ${total.toFixed(2).replace('.', ',')}*`;

      setTimeout(() => {
        window.open(`https://wa.me/${PIZZARIA_PHONE}?text=${encodeURIComponent(msg)}`, '_blank');
        setCart([]);
        setIsOrderFinished(false);
        setIsProcessing(false);
      }, 2000);
    } catch (error) {
      alert("Erro ao enviar pedido.");
      setIsProcessing(false);
    }
  };

  const filteredMenu = useMemo(() => {
    return menu.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === 'All' || item.category === category;
      return matchesSearch && matchesCategory;
    });
  }, [search, category, menu]);

  const categoriesList = useMemo(() => ['All', ...Array.from(new Set(menu.map(i => i.category)))], [menu]);

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: siteConfig.backgroundColor }}>
      {/* Navbar Moderna */}
      <nav className="sticky top-0 z-[60] glass border-b-4 border-hunger-yellow px-6 py-4 shadow-2xl transition-all duration-300">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4 cursor-pointer" onClick={() => setActiveTab('menu')}>
            <div className="w-14 h-14 bg-hunger-red rounded-2xl flex items-center justify-center text-hunger-yellow shadow-xl border-2 border-hunger-yellow font-brand text-4xl rotate-3">
               {siteConfig.appName[0]}
            </div>
            <div className="hidden sm:block">
              <h1 className="font-brand text-3xl text-hunger-red leading-none italic uppercase tracking-tighter">{siteConfig.appName}</h1>
              <p className="text-[10px] font-black text-hunger-orange uppercase tracking-[0.3em] mt-1">{siteConfig.appSlogan}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => isAdmin ? setActiveTab(activeTab === 'menu' ? 'admin' : 'menu') : setIsAuthModalOpen(true)} className={`px-5 py-3 rounded-2xl font-black text-[10px] uppercase transition-all flex items-center gap-2 ${isAdmin ? 'bg-hunger-green text-white shadow-hunger-green/20' : 'bg-stone-100 text-stone-400 hover:bg-stone-200'}`}>
               {isAdmin ? (activeTab === 'menu' ? '🛠️ Painel ADM' : '👁️ Ver Loja') : '🔒 Admin'}
            </button>
            <button onClick={() => setIsProfileModalOpen(true)} className="flex items-center gap-2 bg-white px-5 py-3 rounded-2xl shadow-lg border-2 border-hunger-yellow hover:scale-105 transition-all">
              <span className="text-xl">👤</span>
              <span className="hidden md:inline text-[10px] font-black uppercase text-hunger-dark">
                {userProfile ? `Olá, ${userProfile.name.split(' ')[0]}` : "Cadastrar"}
              </span>
            </button>
            <div ref={cartRef} className="relative bg-hunger-red text-white p-4 rounded-2xl shadow-2xl cursor-pointer border-4 border-hunger-yellow group active:scale-90 transition-transform" onClick={() => document.getElementById('checkout-section')?.scrollIntoView({ behavior: 'smooth' })}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0"/></svg>
              {cart.length > 0 && <span className="absolute -top-3 -right-3 bg-hunger-yellow text-hunger-red text-[12px] font-black w-8 h-8 flex items-center justify-center rounded-full border-2 border-white shadow-xl animate-in zoom-in">{cart.reduce((a,b)=>a+b.quantity,0)}</span>}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 pt-12">
        {activeTab === 'menu' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-12">
              {/* Hero */}
              <section className="rounded-[3.5rem] p-12 text-white relative overflow-hidden flex flex-col justify-between min-h-[480px] shadow-2xl" style={{ backgroundColor: siteConfig.primaryColor }}>
                   <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                   <div className="relative z-10">
                      <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/15 rounded-full text-hunger-yellow text-[11px] font-black uppercase tracking-[0.3em] mb-8 border border-white/20 backdrop-blur-md">
                        <span className="w-2.5 h-2.5 bg-green-400 rounded-full animate-pulse"></span>
                        Chef IA Online
                      </span>
                      <h2 className="text-8xl font-brand leading-[0.8] tracking-tighter uppercase italic drop-shadow-2xl">
                        {siteConfig.heroTitle} <br/> 
                        {siteConfig.heroSubtitle} <br/>
                        <span className="text-hunger-yellow">{siteConfig.heroHighlight}</span>
                      </h2>
                   </div>
                   <div className="relative mt-12 z-10 flex flex-col sm:flex-row items-center gap-6">
                      <button onClick={openAiChat} className="group bg-white text-hunger-red px-14 py-7 rounded-3xl text-xl font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 shadow-2xl border-b-8 border-stone-200">
                        <span className="flex items-center gap-4">
                          <span className="text-4xl group-hover:rotate-12 transition-transform">🧑‍🍳</span>
                          Ajudar a Escolher
                        </span>
                      </button>
                   </div>
              </section>

              {/* Menu & Search */}
              <div className="flex flex-col md:flex-row gap-6 items-center bg-white p-7 rounded-[2.5rem] shadow-xl border-4 border-hunger-yellow/20">
                 <div className="flex-1 w-full relative">
                    <input type="text" placeholder="Qual sabor te apetece?" value={search} onChange={(e) => setSearch(e.target.value)} className="w-full py-6 px-16 bg-hunger-cream rounded-3xl border-4 border-stone-50 focus:ring-4 focus:ring-hunger-red transition-all text-lg font-bold placeholder-stone-400 outline-none" />
                    <svg className="absolute left-6 top-1/2 -translate-y-1/2 text-hunger-red opacity-40" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                 </div>
                 <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 w-full md:w-auto">
                    {categoriesList.map(cat => (
                      <button key={cat} onClick={() => setCategory(cat)} className={`px-10 py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${category === cat ? 'bg-hunger-red text-white shadow-xl scale-105 border-b-4 border-hunger-dark/20' : 'bg-stone-50 text-stone-400 hover:text-hunger-red'}`}>
                        {cat}
                      </button>
                    ))}
                 </div>
              </div>

              <section className="grid grid-cols-1 md:grid-cols-2 gap-10 pb-12">
                {isLoadingMenu ? (
                  <div className="col-span-full py-48 text-center"><p className="animate-pulse font-black text-hunger-red uppercase tracking-widest text-2xl">🔥 Aquecendo o Forno...</p></div>
                ) : filteredMenu.map(item => <PizzaCard key={item.id} pizza={item} onAdd={addToCart} />)}
              </section>
            </div>

            {/* Sidebar Checkout */}
            <div className="lg:col-span-5" id="checkout-section">
              <div className="sticky top-32">
                <div className="bg-white rounded-[4rem] shadow-2xl border-4 border-hunger-yellow overflow-hidden flex flex-col max-h-[85vh]">
                  <div className="p-10 bg-hunger-red text-white flex items-center justify-between shrink-0 shadow-xl border-b-8 border-hunger-dark/10">
                    <h3 className="font-brand text-4xl uppercase italic leading-none">Minha Sacola</h3>
                    <div className="bg-hunger-yellow text-hunger-red px-6 py-4 rounded-2xl font-black text-2xl shadow-inner border-2 border-white">
                       {cart.reduce((a,b)=>a+b.quantity,0)}
                    </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-hunger-cream/20 no-scrollbar">
                    {cart.length === 0 ? (
                      <div className="text-center py-24 opacity-20">
                         <div className="text-9xl mb-6">📦</div>
                         <p className="font-black uppercase text-xs tracking-[0.2em]">Sacola vazia</p>
                      </div>
                    ) : cart.map(item => (
                        <div key={item.id} className="flex gap-5 bg-white p-5 rounded-[2.5rem] shadow-lg border-2 border-hunger-yellow/10 animate-in slide-in-from-right-6">
                           <img src={item.image} className="w-16 h-16 rounded-2xl object-cover shadow-md" />
                           <div className="flex-1">
                              <h4 className="font-black text-sm uppercase text-hunger-dark">{item.name}</h4>
                              <div className="flex justify-between items-center mt-2">
                                 <div className="flex items-center gap-3 bg-stone-50 rounded-xl px-3 py-1 border border-stone-100">
                                    <button onClick={() => updateQuantity(item.id, -1)} className="font-black text-hunger-red">−</button>
                                    <span className="font-black text-xs w-4 text-center">{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item.id, 1)} className="font-black text-hunger-red">+</button>
                                 </div>
                                 <span className="font-black text-hunger-red">R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}</span>
                              </div>
                           </div>
                        </div>
                    ))}
                  </div>

                  <div className="p-8 bg-white border-t-4 border-hunger-yellow/20 space-y-6">
                    <div className="flex justify-between items-end bg-hunger-yellow/10 p-5 rounded-3xl border-2 border-hunger-yellow/20">
                       <div>
                          <p className="font-black uppercase text-[10px] text-stone-400 tracking-widest">Valor Total</p>
                          <p className="text-4xl font-brand text-hunger-red italic leading-none">R$ {total.toFixed(2).replace('.', ',')}</p>
                       </div>
                       <div className="w-12 h-12 bg-hunger-red rounded-full flex items-center justify-center text-white shadow-xl animate-pulse">
                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><path d="M20 6 9 17l-5-5"/></svg>
                       </div>
                    </div>
                    
                    <div className="space-y-3">
                       {userProfile ? (
                         <div className="bg-stone-50 p-5 rounded-3xl border-2 border-hunger-yellow/10 relative">
                            <button onClick={() => setIsProfileModalOpen(true)} className="absolute top-4 right-4 text-hunger-red text-[8px] font-black uppercase underline tracking-tighter">Trocar</button>
                            <p className="text-[10px] font-black text-hunger-red uppercase tracking-widest mb-2 flex items-center gap-2">
                               <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                               Entrega para:
                            </p>
                            <p className="font-black text-sm text-hunger-dark uppercase">{userProfile.name}</p>
                            <p className="text-[11px] font-bold text-stone-500 mt-1 leading-tight">{userProfile.rua}, {userProfile.numero} - {userProfile.bairro}</p>
                         </div>
                       ) : (
                         <button onClick={() => setIsProfileModalOpen(true)} className="w-full py-6 bg-hunger-cream border-4 border-hunger-red border-dashed rounded-[2rem] flex flex-col items-center justify-center gap-2 hover:bg-hunger-red/5 transition-all">
                            <span className="text-2xl">📝</span>
                            <span className="text-[11px] font-black uppercase text-hunger-red tracking-widest">Cadastrar Endereço</span>
                         </button>
                       )}

                       <div className="grid grid-cols-2 gap-2">
                          {['Pix', 'Cartão de Crédito', 'Cartão de Débito', 'Dinheiro'].map(m => (
                            <button key={m} onClick={() => setPayment(m)} className={`p-4 rounded-2xl border-4 font-black text-[10px] uppercase transition-all ${payment === m ? 'border-hunger-red bg-hunger-red text-white' : 'border-stone-50 bg-stone-50 text-stone-400'}`}>
                              {m}
                            </button>
                          ))}
                       </div>
                       {payment === 'Dinheiro' && <input type="text" placeholder="Troco para quanto?" value={changeFor} onChange={e => setChangeFor(e.target.value)} className="w-full p-5 border-4 border-hunger-red/30 rounded-2xl font-black text-sm" />}
                    </div>

                    <button onClick={handleSubmitOrder} disabled={isProcessing} className={`group relative w-full py-8 rounded-[3rem] font-black text-lg tracking-[0.4em] uppercase transition-all shadow-2xl flex items-center justify-center gap-6 overflow-hidden ${cart.length > 0 && userProfile ? 'bg-hunger-red text-white hover:scale-105 border-b-[10px] border-hunger-dark/20' : 'bg-stone-100 text-stone-300'}`}>
                       {isProcessing ? <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div> : <>FECHAR PEDIDO 📲</>}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* PAINEL ADMINISTRATIVO */
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-500 space-y-12 pb-32">
             <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white p-10 rounded-[4rem] shadow-xl border-4 border-hunger-green/20">
                <div>
                  <h2 className="font-brand text-5xl text-hunger-green uppercase italic">Painel de Gestão</h2>
                  <p className="font-bold text-stone-400 uppercase tracking-widest text-[11px] mt-2">Personalize sua pizzaria em tempo real</p>
                </div>
                <div className="flex gap-4">
                  <button onClick={saveAdminChanges} disabled={isUpdatingConfig} className="bg-hunger-green text-white px-10 py-5 rounded-3xl font-black uppercase text-xs shadow-xl border-b-8 border-hunger-dark/10 hover:scale-105 active:scale-95 transition-all">
                    {isUpdatingConfig ? "Salvando..." : "💾 Salvar Tudo"}
                  </button>
                </div>
             </header>

             <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                {/* Branding & Config */}
                <div className="lg:col-span-4 space-y-8">
                   <div className="bg-white p-10 rounded-[3.5rem] shadow-xl space-y-8 border-4 border-stone-100">
                      <h3 className="font-brand text-3xl uppercase text-hunger-red">Identidade Visual</h3>
                      <div className="space-y-6">
                         <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Nome da Pizzaria</label>
                            <input type="text" value={siteConfig.appName} onChange={e => setSiteConfig({...siteConfig, appName: e.target.value})} className="w-full p-5 bg-stone-50 border-2 border-stone-100 rounded-2xl font-bold" />
                         </div>
                         <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Slogan</label>
                            <input type="text" value={siteConfig.appSlogan} onChange={e => setSiteConfig({...siteConfig, appSlogan: e.target.value})} className="w-full p-5 bg-stone-50 border-2 border-stone-100 rounded-2xl font-bold" />
                         </div>
                         <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Título do Banner</label>
                            <input type="text" value={siteConfig.heroTitle} onChange={e => setSiteConfig({...siteConfig, heroTitle: e.target.value})} className="w-full p-5 bg-stone-50 border-2 border-stone-100 rounded-2xl font-bold" />
                         </div>
                         <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Destaque Banner</label>
                            <input type="text" value={siteConfig.heroHighlight} onChange={e => setSiteConfig({...siteConfig, heroHighlight: e.target.value})} className="w-full p-5 bg-stone-50 border-2 border-stone-100 rounded-2xl font-bold" />
                         </div>
                         <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Cor Principal</label>
                               <input type="color" value={siteConfig.primaryColor} onChange={e => setSiteConfig({...siteConfig, primaryColor: e.target.value})} className="w-full h-16 rounded-2xl cursor-pointer" />
                            </div>
                            <div className="space-y-2">
                               <label className="text-[10px] font-black uppercase text-stone-400 tracking-widest ml-2">Fundo Site</label>
                               <input type="color" value={siteConfig.backgroundColor} onChange={e => setSiteConfig({...siteConfig, backgroundColor: e.target.value})} className="w-full h-16 rounded-2xl cursor-pointer" />
                            </div>
                         </div>
                      </div>
                   </div>
                </div>

                {/* Produtos Management */}
                <div className="lg:col-span-8 space-y-8">
                   <div className="bg-white p-10 rounded-[3.5rem] shadow-xl border-4 border-stone-100">
                      <div className="flex items-center justify-between mb-10">
                         <h3 className="font-brand text-3xl uppercase text-hunger-red">Gerenciar Cardápio</h3>
                         <button onClick={handleAddProduct} className="bg-hunger-red text-white px-8 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-lg active:scale-95 transition-all">
                           ➕ Novo Produto
                         </button>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                         {menu.map(item => (
                           <div key={item.id} className="relative group">
                              <PizzaCard pizza={item} onAdd={() => {}} isAdminMode={true} onUpdate={handleUpdateProduct} />
                              <button onClick={() => handleDeleteProduct(item.id)} className="absolute -top-4 -right-4 bg-hunger-red text-white w-12 h-12 rounded-full shadow-2xl flex items-center justify-center border-4 border-white hover:scale-110 transition-all">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><path d="M18 6L6 18M6 6l12 12"/></svg>
                              </button>
                           </div>
                         ))}
                      </div>
                   </div>
                </div>
             </div>
          </div>
        )}
      </main>

      {/* MODAL CADASTRO */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-[120] bg-hunger-dark/95 backdrop-blur-3xl flex items-center justify-center p-4 animate-in fade-in">
           <div className="bg-white rounded-[4rem] w-full max-w-xl shadow-2xl overflow-hidden border-8 border-hunger-yellow animate-in zoom-in duration-300">
              <div className="p-8 bg-hunger-red text-white flex items-center justify-between">
                 <h3 className="font-brand text-3xl uppercase italic tracking-tight">Identificação</h3>
                 <button onClick={() => setIsProfileModalOpen(false)} className="text-white hover:rotate-90 transition-transform p-2 bg-white/10 rounded-full">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><path d="M18 6 6 18M6 6l12 12"/></svg>
                 </button>
              </div>
              <form onSubmit={handleSaveProfile} className="p-10 space-y-6">
                 <div className="space-y-4">
                    <p className="text-[10px] font-black text-hunger-red uppercase tracking-widest">Seus Dados</p>
                    <input type="text" placeholder="Nome Completo" value={profileForm.name} onChange={e => setProfileForm({...profileForm, name: e.target.value})} className="w-full p-5 bg-stone-50 border-4 border-stone-100 rounded-[1.5rem] font-bold outline-none focus:border-hunger-yellow transition-all" required />
                    <input type="tel" placeholder="WhatsApp" value={profileForm.phone} onChange={e => setProfileForm({...profileForm, phone: e.target.value})} className="w-full p-5 bg-stone-50 border-4 border-stone-100 rounded-[1.5rem] font-bold outline-none focus:border-hunger-yellow transition-all" required />
                 </div>
                 <div className="space-y-4">
                    <p className="text-[10px] font-black text-hunger-red uppercase tracking-widest">Onde Entregar?</p>
                    <input type="text" placeholder="Rua / Avenida" value={profileForm.rua} onChange={e => setProfileForm({...profileForm, rua: e.target.value})} className="w-full p-5 bg-stone-50 border-4 border-stone-100 rounded-[1.5rem] font-bold outline-none focus:border-hunger-yellow transition-all" required />
                    <div className="grid grid-cols-3 gap-3">
                       <input type="text" placeholder="Nº" value={profileForm.numero} onChange={e => setProfileForm({...profileForm, numero: e.target.value})} className="p-5 bg-stone-50 border-4 border-stone-100 rounded-[1.5rem] font-bold text-center outline-none focus:border-hunger-yellow transition-all" required />
                       <input type="text" placeholder="Bairro" value={profileForm.bairro} onChange={e => setProfileForm({...profileForm, bairro: e.target.value})} className="col-span-2 p-5 bg-stone-50 border-4 border-stone-100 rounded-[1.5rem] font-bold outline-none focus:border-hunger-yellow transition-all" required />
                    </div>
                 </div>
                 <button type="submit" className="w-full py-7 bg-hunger-red text-white rounded-[2rem] font-black uppercase tracking-widest shadow-xl border-b-[8px] border-hunger-dark/20 hover:scale-105 active:scale-95 transition-all">SALVAR DADOS ✅</button>
              </form>
           </div>
        </div>
      )}

      {/* MODAL AUTH ADMIN */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-[120] bg-hunger-dark/95 backdrop-blur-2xl flex items-center justify-center p-4">
           <div className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl border-4 border-hunger-green">
              <h3 className="font-brand text-3xl text-hunger-green mb-6 uppercase text-center">Acesso Restrito</h3>
              <input type="password" placeholder="Digite a Senha" value={passwordInput} onChange={e => setPasswordInput(e.target.value)} className="w-full p-5 bg-stone-50 border-2 border-stone-100 rounded-2xl mb-4 font-bold text-center text-xl" />
              <div className="flex gap-2">
                 <button onClick={() => setIsAuthModalOpen(false)} className="flex-1 py-4 font-black uppercase text-[10px] text-stone-400">Cancelar</button>
                 <button onClick={handleAdminAuth} className="flex-[2] bg-hunger-green text-white py-4 rounded-xl font-black uppercase text-[10px] shadow-lg">Entrar 🔒</button>
              </div>
           </div>
        </div>
      )}

      {/* MODAL CHEF IA */}
      {isAiChatOpen && (
        <div className="fixed inset-0 z-[100] bg-hunger-dark/95 backdrop-blur-2xl flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="bg-white rounded-[4rem] w-full max-w-3xl h-[85vh] flex flex-col shadow-2xl overflow-hidden border-8 border-hunger-yellow animate-in zoom-in duration-300">
              <div className="p-10 bg-hunger-red text-white flex items-center justify-between shrink-0 shadow-xl relative">
                 <div className="flex items-center gap-6 relative z-10">
                    <div className="relative">
                      <div className="w-20 h-20 bg-hunger-yellow rounded-full flex items-center justify-center text-5xl shadow-xl animate-bounce border-4 border-white">🧑‍🍳</div>
                      <div className="absolute bottom-1 right-1 w-5 h-5 bg-green-400 rounded-full border-2 border-hunger-red"></div>
                    </div>
                    <div>
                       <h3 className="font-brand text-4xl uppercase leading-none tracking-tight">Chef {siteConfig.appName}</h3>
                       <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-70 mt-2 flex items-center gap-2">
                          <span className="w-2 h-2 bg-green-400 rounded-full"></span> Online
                       </p>
                    </div>
                 </div>
                 <button onClick={() => setIsAiChatOpen(false)} className="bg-white/10 p-5 rounded-3xl hover:bg-white/20 transition-all hover:rotate-90">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="5"><path d="M18 6 6 18M6 6l12 12"/></svg>
                 </button>
              </div>
              <div className="flex-1 overflow-y-auto p-10 space-y-8 no-scrollbar bg-[#FDFDFD]">
                 {aiMessages.map((msg, i) => (
                   <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-6 duration-500`}>
                      <div className={`max-w-[85%] p-8 rounded-[3rem] shadow-xl font-bold text-lg leading-relaxed relative ${msg.role === 'user' ? 'bg-hunger-red text-white rounded-tr-none' : 'bg-white text-hunger-dark rounded-tl-none border-4 border-hunger-yellow/10'}`}>
                         {msg.text.split(/(\[.*?\])/).map((part, index) => {
                           if (part.startsWith('[') && part.endsWith(']')) {
                             const pName = part.slice(1, -1);
                             return (
                               <button key={index} onClick={() => addToCartFromChat(pName)} className="mt-6 flex items-center justify-between w-full bg-hunger-yellow text-hunger-red py-6 px-8 rounded-3xl font-black uppercase text-xs shadow-xl hover:scale-105 active:scale-95 transition-all">
                                 <span>🛒 Adicionar {pName.toUpperCase()}</span>
                                 <span className="text-xl">✨</span>
                               </button>
                             );
                           }
                           return part;
                         })}
                      </div>
                   </div>
                 ))}
                 {isAiTyping && <div className="flex justify-start"><div className="bg-stone-50 p-8 rounded-[3rem] rounded-tl-none flex gap-3"><span className="w-3 h-3 bg-hunger-red/20 rounded-full animate-bounce"></span><span className="w-3 h-3 bg-hunger-red/40 rounded-full animate-bounce delay-100"></span><span className="w-3 h-3 bg-hunger-red/60 rounded-full animate-bounce delay-200"></span></div></div>}
                 <div ref={chatEndRef} />
              </div>
              <form onSubmit={handleSendMessage} className="p-10 bg-white border-t-8 border-hunger-cream flex gap-4 shrink-0">
                 <input type="text" value={userInput} onChange={e => setUserInput(e.target.value)} placeholder="Manda sua dúvida sobre o cardápio..." className="flex-1 p-8 bg-hunger-cream/30 border-4 border-stone-50 rounded-[2.5rem] font-black text-xl outline-none focus:border-hunger-red/10 transition-all placeholder-stone-300" />
                 <button type="submit" className="bg-hunger-red text-white p-8 rounded-3xl shadow-2xl hover:scale-110 active:scale-90 transition-all">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="5"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                 </button>
              </form>
           </div>
        </div>
      )}

      {/* OVERLAY SUCESSO PEDIDO */}
      {isOrderFinished && (
        <div className="fixed inset-0 z-[150] bg-hunger-red flex items-center justify-center text-center p-8 animate-in fade-in duration-500">
           <div className="space-y-8 animate-in zoom-in duration-700">
              <div className="w-32 h-32 bg-white rounded-full mx-auto flex items-center justify-center text-hunger-red text-6xl shadow-2xl animate-bounce border-8 border-hunger-yellow">✓</div>
              <h2 className="text-6xl font-brand text-white uppercase italic">SABOR EM CAMINHO!</h2>
              <p className="text-white/80 font-black tracking-widest uppercase text-xs">Abrindo WhatsApp para confirmação definitiva...</p>
           </div>
        </div>
      )}
    </div>
  );
};

export default App;
