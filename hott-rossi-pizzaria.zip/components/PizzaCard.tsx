
import React, { useState, useRef } from 'react';
import { Pizza } from '../types';

interface PizzaCardProps {
  pizza: Pizza;
  onAdd: (pizza: Pizza) => void;
  isAdminMode?: boolean;
  onUpdate?: (updatedPizza: Pizza) => void;
  stock?: number;
}

const PizzaCard: React.FC<PizzaCardProps> = ({ pizza, onAdd, isAdminMode, onUpdate, stock = 10 }) => {
  const [isAdding, setIsAdding] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAdd = () => {
    setIsAdding(true);
    onAdd(pizza);
    setTimeout(() => setIsAdding(false), 800);
  };

  const handlePriceChange = (val: string) => {
    if (!onUpdate) return;
    const cleanVal = val.replace(',', '.');
    onUpdate({ ...pizza, price: parseFloat(cleanVal) || 0 });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onUpdate) {
      if (!file.type.match('image.*')) {
        alert("Por favor, selecione apenas arquivos de imagem (JPG, PNG, etc).");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdate({ ...pizza, image: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  if (isAdminMode && onUpdate) {
    return (
      <div className="group bg-white rounded-[2.5rem] shadow-xl p-8 border-2 border-hunger-red/10 animate-in zoom-in duration-300 ring-4 ring-hunger-orange/5 relative">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="font-brand text-2xl text-hunger-red tracking-wide uppercase">Editar Sabor</h4>
            <span className="text-[10px] font-black bg-hunger-yellow/20 text-hunger-red px-3 py-1 rounded-full uppercase tracking-widest">{pizza.category}</span>
          </div>
          
          <div className="relative h-40 w-full rounded-2xl overflow-hidden bg-stone-100 group/img">
            <img 
              src={pizza.image || 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=400'} 
              className="w-full h-full object-cover opacity-60" 
              alt="" 
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 flex flex-col items-center justify-center bg-hunger-dark/60 opacity-0 group-hover/img:opacity-100 transition-all text-white"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="mb-2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              <span className="text-[9px] font-black uppercase tracking-widest">Alterar Foto</span>
            </button>
            <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
          </div>

          <div className="space-y-4">
            <div className="relative">
              <input type="text" value={pizza.name} onChange={(e) => onUpdate({ ...pizza, name: e.target.value })} className="w-full px-5 py-3 pt-7 bg-hunger-cream border-stone-200 border rounded-xl text-sm font-bold focus:ring-2 focus:ring-hunger-orange outline-none" placeholder="Nome" />
              <span className="absolute left-5 top-2 text-[8px] font-black uppercase text-stone-400">Nome</span>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <input type="text" value={pizza.price.toString().replace('.', ',')} onChange={(e) => handlePriceChange(e.target.value)} className="w-full px-5 py-3 pt-7 bg-hunger-cream border-stone-200 border rounded-xl text-sm font-bold focus:ring-2 focus:ring-hunger-orange outline-none" placeholder="Preço" />
                <span className="absolute left-5 top-2 text-[8px] font-black uppercase text-stone-400">Preço (R$)</span>
              </div>
              <div className="relative">
                <input type="text" value={pizza.category} onChange={(e) => onUpdate({ ...pizza, category: e.target.value })} className="w-full px-5 py-3 pt-7 bg-hunger-cream border-stone-200 border rounded-xl text-sm font-bold focus:ring-2 focus:ring-hunger-orange outline-none" placeholder="Categoria" />
                <span className="absolute left-5 top-2 text-[8px] font-black uppercase text-stone-400">Categoria</span>
              </div>
            </div>

            <div className="relative">
              <textarea value={pizza.description} onChange={(e) => onUpdate({ ...pizza, description: e.target.value })} className="w-full px-5 py-3 pt-7 bg-hunger-cream border-stone-200 border rounded-xl text-sm font-bold focus:ring-2 focus:ring-hunger-orange outline-none resize-none" rows={2} placeholder="Ingredientes" />
              <span className="absolute left-5 top-2 text-[8px] font-black uppercase text-stone-400">Descrição</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group bg-white rounded-[2.5rem] shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 flex flex-col border border-hunger-yellow/20 overflow-hidden relative">
      <div className="h-64 overflow-hidden relative">
        <img 
          src={pizza.image || 'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop'} 
          alt={pizza.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
        />
        
        <div className="absolute bottom-4 right-4 bg-hunger-red px-6 py-2.5 rounded-2xl shadow-xl border-2 border-hunger-yellow transform group-hover:scale-110 transition-transform">
           <span className="text-hunger-yellow text-xs font-black uppercase tracking-widest mr-1">R$</span>
           <span className="text-white text-2xl font-black">{pizza.price.toFixed(2).replace('.', ',')}</span>
        </div>

        <div className="absolute top-4 left-4 bg-hunger-yellow text-hunger-red text-[10px] font-black uppercase tracking-[0.2em] px-4 py-2 rounded-full shadow-lg border-2 border-white">
          {pizza.category}
        </div>

        {isAdding && (
          <div className="absolute inset-0 bg-hunger-yellow/60 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-300">
             <div className="bg-hunger-red p-6 rounded-full shadow-2xl animate-bounce border-4 border-white">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
             </div>
          </div>
        )}
      </div>

      <div className="p-8 flex-1 flex flex-col bg-white">
        <div className="flex-1">
          <h3 className="text-2xl font-impact tracking-tight text-hunger-dark group-hover:text-hunger-red transition-colors uppercase">{pizza.name}</h3>
          <p className="text-stone-500 text-sm mt-3 leading-relaxed font-medium italic line-clamp-2">
            {pizza.description}
          </p>
        </div>

        <button 
          onClick={handleAdd}
          className="mt-8 w-full bg-hunger-red text-white py-5 rounded-2xl font-black text-xs tracking-[0.2em] uppercase hover:bg-hunger-orange transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-hunger-red/30 border-b-4 border-hunger-dark/20 overflow-hidden relative"
        >
          <div className="absolute inset-0 shimmer opacity-20"></div>
          {isAdding ? 'SABOR ADICIONADO!' : (
            <>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><path d="M5 12h14M12 5v14"/></svg>
              QUERO ESTA DELÍCIA
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default PizzaCard;
