
import { Pizza, SiteConfig } from './types';

export const MENU_ITEMS: Pizza[] = [
  { 
    id: 1, 
    name: "Calabresa Especial", 
    description: "Mussarela, calabresa premium fatiada, cebola roxa e orégano.", 
    price: 45.00, 
    category: 'Pizza', 
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=400" 
  },
  { 
    id: 2, 
    name: "Mussarela Tradicional", 
    description: "Mussarela de búfala, rodelas de tomate fresco e manjericão.", 
    price: 42.00, 
    category: 'Pizza', 
    image: "https://images.unsplash.com/photo-1574071318508-1cdbad80ad38?q=80&w=400" 
  },
  { 
    id: 3, 
    name: "Portuguesa Completa", 
    description: "Mussarela, presunto cozido, ovos, cebola, ervilha e palmito.", 
    price: 48.00, 
    category: 'Pizza', 
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=400" 
  },
  { 
    id: 4, 
    name: "Frango com Catupiry", 
    description: "Frango desfiado temperado, milho e o legítimo Catupiry.", 
    price: 50.00, 
    category: 'Pizza', 
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?q=80&w=400" 
  }
];

export const DEFAULT_CONFIG: SiteConfig = {
  appName: "Hott Rossi",
  appSlogan: "O Sabor que Alucina",
  heroTitle: "O Sabor",
  heroSubtitle: "Que Faltava",
  heroHighlight: "Na Noite.",
  heroEmoji: "🍕",
  sideBoxTitle: "Tradição",
  sideBoxSubtitle: "Hott Rossi",
  sideBoxEmoji: "🏰",
  primaryColor: "#D62300", // Vermelho
  secondaryColor: "#FF8C00", // Laranja
  accentColor: "#FFCC00", // Amarelo
  backgroundColor: "#FFF9F0" // Creme
};

export const PIZZARIA_PHONE = "5511992525810";
