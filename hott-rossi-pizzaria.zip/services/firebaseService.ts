
import { initializeApp } from "firebase/app";
import { getDatabase, ref, push, set, get, child } from "firebase/database";
import { OrderData, Pizza, SiteConfig } from "../types";

const firebaseConfig = {
  apiKey: "AIzaSyDhb3_9NcAFgi-LDHRyvzr7Hk5171uM8Z0",
  authDomain: "hott-hossi.firebaseapp.com",
  databaseURL: "https://hott-hossi-default-rtdb.firebaseio.com",
  projectId: "hott-hossi",
  storageBucket: "hott-hossi.firebasestorage.app",
  messagingSenderId: "725721044596",
  appId: "1:725721044596:web:29383c4fb3e0aea40a2321",
  measurementId: "G-CB8WN1G5MN"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export const saveOrder = async (order: OrderData) => {
  const ordersRef = ref(db, 'pedidos');
  const newOrderRef = push(ordersRef);
  return set(newOrderRef, order);
};

export const getMenu = async (): Promise<Pizza[] | null> => {
  const dbRef = ref(db);
  const snapshot = await get(child(dbRef, `cardapio`));
  if (snapshot.exists()) {
    return snapshot.val();
  }
  return null;
};

export const updateMenu = async (menu: Pizza[]) => {
  const menuRef = ref(db, 'cardapio');
  return set(menuRef, menu);
};

export const getConfig = async (): Promise<SiteConfig | null> => {
  const dbRef = ref(db);
  const snapshot = await get(child(dbRef, `config`));
  if (snapshot.exists()) {
    return snapshot.val();
  }
  return null;
};

export const updateConfig = async (config: SiteConfig) => {
  const configRef = ref(db, 'config');
  return set(configRef, config);
};
