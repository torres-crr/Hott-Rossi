
import { GoogleGenAI, Chat } from "@google/genai";
import { Pizza } from "../types";

// Always use process.env.API_KEY directly when initializing the GoogleGenAI client instance
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const startChefChat = (currentMenu: Pizza[]): Chat => {
  const menuStr = currentMenu.map(i => `- ${i.name} (R$ ${i.price}): ${i.description}`).join('\n');
  
  return ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `Você é o Chef Hott Rossi da Hott Rossi Pizzaria. 
      Seu objetivo é ser extremamente simpático, carismático e ajudar o cliente a escolher a pizza perfeita.
      
      REGRAS:
      1. Use o cardápio real:
      ${menuStr}
      
      2. Se o cliente descrever um desejo, recomende UMA pizza específica do cardápio.
      3. Seja breve e use emojis de comida e italiano.
      4. Sempre que sugerir uma pizza, termine sua frase com o nome exato da pizza entre colchetes, ex: [Calabresa Especial]. Isso criará um botão de compra.
      5. Se o cliente estiver indeciso, faça perguntas sobre preferências (picante, doce, queijo, leve).`,
      temperature: 0.8,
    },
  });
};

export const getCartFeedback = async (cartItems: any[]): Promise<string> => {
  if (cartItems.length === 0) return "";
  try {
    const itemsStr = cartItems.map(i => `${i.quantity}x ${i.name}`).join(', ');
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `O cliente adicionou os seguintes itens ao carrinho: ${itemsStr}. 
      Dê um comentário curtíssimo e simpático (máximo 12 palavras) sobre essa escolha.`,
    });
    // The text property directly returns the string output. Do not use response.text().
    return response.text?.trim() || "Bela escolha! 🍕";
  } catch (e) {
    return "Escolha de mestre! 🍕";
  }
};
