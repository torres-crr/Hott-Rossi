
export interface Pizza {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: string;
}

export interface CartItem extends Pizza {
  quantity: number;
}

export interface UserProfile {
  name: string;
  phone: string;
  rua: string;
  numero: string;
  bairro: string;
  complemento?: string;
}

export interface OrderData {
  cliente: string;
  telefone: string;
  endereco: {
    rua: string;
    numero: string;
    bairro: string;
    complemento?: string;
  };
  pagamento: string;
  troco?: string;
  itens: CartItem[];
  total: number;
  data_hora: string;
}

export interface SiteConfig {
  appName: string;
  appSlogan: string;
  heroTitle: string;
  heroSubtitle: string;
  heroHighlight: string;
  heroEmoji: string;
  sideBoxTitle: string;
  sideBoxSubtitle: string;
  sideBoxEmoji: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
}
